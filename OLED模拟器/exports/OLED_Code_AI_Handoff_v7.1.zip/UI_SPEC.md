# Curing_Lite 光固化机 128x32 OLED OLED UI Specification

> Generated from scene JSON. Do not edit this document as the layout source of truth.

## Global Contract

- Canvas: **128×32**, monochrome 1-bit.
- Origin: `(0,0)` at top-left; X increases right, Y increases down.
- Bounds: `[x, x+w) × [y, y+h)`.
- Storage: **512-byte VLSB**, 4 pages × 128 columns; bit0 is the top pixel of each 8-pixel page.
- Polarity: `1 = OLED lit`, `0 = background`.
- Bitmap resize policy: `native_only` unless explicitly stated otherwise.
- Bitmap source polarity is normalized at load time: opaque black-on-white assets are inverted in memory; source files are not rewritten.

## Scene Element Definitions

| ID | Type | X | Y | W | H | Binding / Text |
|---|---|---:|---:|---:|---:|---|
| battery | image_seq | 5 | 2 | 11 | 28 | battery |
| hero_digits | digits | 45 | 3 |  |  | seconds |
| mode_label | text | 88 | 4 | 36 | 12 | {mode} |
| mode_icon | image | 94 | 19 | 24 | 12 |  |
| running_icon | image | 94 | 19 | 24 | 12 |  |

## CHECK_RUNNING

State: `battery=3, mode=CHECK, phase=running, seconds=10`

Golden BIN: `golden/check_running.bin`  
Reference PNG: `reference/check_running.png`  
SHA-256: `3a34915ba94cbd8a3cebcdd696dfa94e2f29c39dc6de8f2c95b39dac931800c9`

| ID | Type | X | Y | W | H | Asset / Text |
|---|---|---:|---:|---:|---:|---|
| battery | image_seq | 5 | 2 | 11 | 28 | 电池图标 - 字宽11字高28/11-28电池图标3.png |
| hero_digits | digits | 45 | 3 | 28 | 27 | 10 |
| mode_label | text | 88 | 4 | 29 | 7 | CHECK |
| running_icon | image | 94 | 19 | 24 | 12 | Curing_Lite光固化机产品 - UI设计初稿/running.png |

## CHECK_STANDBY

State: `battery=3, mode=CHECK, phase=standby, seconds=10`

Golden BIN: `golden/check_standby.bin`  
Reference PNG: `reference/check_standby.png`  
SHA-256: `93229e94b299ef0e3291b56234b72ec857c47822609f4af9a3a2d32159ef2c26`

| ID | Type | X | Y | W | H | Asset / Text |
|---|---|---:|---:|---:|---:|---|
| battery | image_seq | 5 | 2 | 11 | 28 | 电池图标 - 字宽11字高28/11-28电池图标3.png |
| hero_digits | digits | 45 | 3 | 28 | 27 | 10 |
| mode_label | text | 88 | 4 | 29 | 7 | CHECK |
| mode_icon | image | 94 | 19 | 24 | 12 | Curing_Lite光固化机产品 - UI设计初稿/check.png |

## HIGH_RUNNING

State: `battery=3, mode=HIGH, phase=running, seconds=10`

Golden BIN: `golden/high_running.bin`  
Reference PNG: `reference/high_running.png`  
SHA-256: `f480d4713ddd11e6f14d978487138ceb04f4524de914e5e42b249da97b5a4ac4`

| ID | Type | X | Y | W | H | Asset / Text |
|---|---|---:|---:|---:|---:|---|
| battery | image_seq | 5 | 2 | 11 | 28 | 电池图标 - 字宽11字高28/11-28电池图标3.png |
| hero_digits | digits | 45 | 3 | 28 | 27 | 10 |
| mode_label | text | 88 | 4 | 23 | 7 | HIGH |
| running_icon | image | 94 | 19 | 24 | 12 | Curing_Lite光固化机产品 - UI设计初稿/running.png |

## HIGH_STANDBY

State: `battery=3, mode=HIGH, phase=standby, seconds=10`

Golden BIN: `golden/high_standby.bin`  
Reference PNG: `reference/high_standby.png`  
SHA-256: `158a31b16217e6ef0b2f163eb9a4a5e6f5fbe1cfbd0acb0968a430cb3a2ad6ab`

| ID | Type | X | Y | W | H | Asset / Text |
|---|---|---:|---:|---:|---:|---|
| battery | image_seq | 5 | 2 | 11 | 28 | 电池图标 - 字宽11字高28/11-28电池图标3.png |
| hero_digits | digits | 45 | 3 | 28 | 27 | 10 |
| mode_label | text | 88 | 4 | 23 | 7 | HIGH |
| mode_icon | image | 94 | 19 | 24 | 12 | Curing_Lite光固化机产品 - UI设计初稿/high.png |

## NORMAL_RUNNING

State: `battery=3, mode=NORMAL, phase=running, seconds=10`

Golden BIN: `golden/normal_running.bin`  
Reference PNG: `reference/normal_running.png`  
SHA-256: `f8ad24e197b0ca98c1fcc29a3f035a7f4f97260fa89d9957fa40431c084dbd5f`

| ID | Type | X | Y | W | H | Asset / Text |
|---|---|---:|---:|---:|---:|---|
| battery | image_seq | 5 | 2 | 11 | 28 | 电池图标 - 字宽11字高28/11-28电池图标3.png |
| hero_digits | digits | 45 | 3 | 28 | 27 | 10 |
| mode_label | text | 88 | 4 | 35 | 7 | NORMAL |
| running_icon | image | 94 | 19 | 24 | 12 | Curing_Lite光固化机产品 - UI设计初稿/running.png |

## NORMAL_STANDBY

State: `battery=3, mode=NORMAL, phase=standby, seconds=10`

Golden BIN: `golden/normal_standby.bin`  
Reference PNG: `reference/normal_standby.png`  
SHA-256: `ea22afed463bf6901ba47cb16ebc0bd8731be605211963402a97992d2ea83849`

| ID | Type | X | Y | W | H | Asset / Text |
|---|---|---:|---:|---:|---:|---|
| battery | image_seq | 5 | 2 | 11 | 28 | 电池图标 - 字宽11字高28/11-28电池图标3.png |
| hero_digits | digits | 45 | 3 | 28 | 27 | 10 |
| mode_label | text | 88 | 4 | 35 | 7 | NORMAL |
| mode_icon | image | 94 | 19 | 24 | 12 | Curing_Lite光固化机产品 - UI设计初稿/normal.png |

## ORTHO_RUNNING

State: `battery=3, mode=ORTHO, phase=running, seconds=10`

Golden BIN: `golden/ortho_running.bin`  
Reference PNG: `reference/ortho_running.png`  
SHA-256: `6046899bb577dcbf1d09be8b95d8502cd07b5de970773a2f90225400b0243ab9`

| ID | Type | X | Y | W | H | Asset / Text |
|---|---|---:|---:|---:|---:|---|
| battery | image_seq | 5 | 2 | 11 | 28 | 电池图标 - 字宽11字高28/11-28电池图标3.png |
| hero_digits | digits | 45 | 3 | 28 | 27 | 10 |
| mode_label | text | 88 | 4 | 29 | 7 | ORTHO |
| running_icon | image | 94 | 19 | 24 | 12 | Curing_Lite光固化机产品 - UI设计初稿/running.png |

## ORTHO_STANDBY

State: `battery=3, mode=ORTHO, phase=standby, seconds=10`

Golden BIN: `golden/ortho_standby.bin`  
Reference PNG: `reference/ortho_standby.png`  
SHA-256: `aa09a66cdc6a5cd29aa9d31d9e8825d698f904aa4b49cb9d988d228f9c2dceb5`

| ID | Type | X | Y | W | H | Asset / Text |
|---|---|---:|---:|---:|---:|---|
| battery | image_seq | 5 | 2 | 11 | 28 | 电池图标 - 字宽11字高28/11-28电池图标3.png |
| hero_digits | digits | 45 | 3 | 28 | 27 | 10 |
| mode_label | text | 88 | 4 | 29 | 7 | ORTHO |
| mode_icon | image | 94 | 19 | 24 | 12 | Curing_Lite光固化机产品 - UI设计初稿/ortho.png |

## PULSE_RUNNING

State: `battery=3, mode=PULSE, phase=running, seconds=10`

Golden BIN: `golden/pulse_running.bin`  
Reference PNG: `reference/pulse_running.png`  
SHA-256: `ab9df3b80766201ef4465e344520dc6c6155d6cf1aab729de032f7ea5ad957b2`

| ID | Type | X | Y | W | H | Asset / Text |
|---|---|---:|---:|---:|---:|---|
| battery | image_seq | 5 | 2 | 11 | 28 | 电池图标 - 字宽11字高28/11-28电池图标3.png |
| hero_digits | digits | 45 | 3 | 28 | 27 | 10 |
| mode_label | text | 88 | 4 | 29 | 7 | PULSE |
| running_icon | image | 94 | 19 | 24 | 12 | Curing_Lite光固化机产品 - UI设计初稿/running.png |

## PULSE_STANDBY

State: `battery=3, mode=PULSE, phase=standby, seconds=10`

Golden BIN: `golden/pulse_standby.bin`  
Reference PNG: `reference/pulse_standby.png`  
SHA-256: `cab6efa640af5fc925c5f15b087ffe1c78043e108ef87e7625f04fb7ea92b6fa`

| ID | Type | X | Y | W | H | Asset / Text |
|---|---|---:|---:|---:|---:|---|
| battery | image_seq | 5 | 2 | 11 | 28 | 电池图标 - 字宽11字高28/11-28电池图标3.png |
| hero_digits | digits | 45 | 3 | 28 | 27 | 10 |
| mode_label | text | 88 | 4 | 29 | 7 | PULSE |
| mode_icon | image | 94 | 19 | 24 | 12 | Curing_Lite光固化机产品 - UI设计初稿/pulse.png |

## RAMP_RUNNING

State: `battery=3, mode=RAMP, phase=running, seconds=10`

Golden BIN: `golden/ramp_running.bin`  
Reference PNG: `reference/ramp_running.png`  
SHA-256: `1f63a1aa96f6866e0d425892b9576713a75962283fcc1dd93eb4776659b206e0`

| ID | Type | X | Y | W | H | Asset / Text |
|---|---|---:|---:|---:|---:|---|
| battery | image_seq | 5 | 2 | 11 | 28 | 电池图标 - 字宽11字高28/11-28电池图标3.png |
| hero_digits | digits | 45 | 3 | 28 | 27 | 10 |
| mode_label | text | 88 | 4 | 23 | 7 | RAMP |
| running_icon | image | 94 | 19 | 24 | 12 | Curing_Lite光固化机产品 - UI设计初稿/running.png |

## RAMP_STANDBY

State: `battery=3, mode=RAMP, phase=standby, seconds=10`

Golden BIN: `golden/ramp_standby.bin`  
Reference PNG: `reference/ramp_standby.png`  
SHA-256: `6b4ca568257d797a8727f96b06126bc1c6285175548a69df5effd5c95d80b900`

| ID | Type | X | Y | W | H | Asset / Text |
|---|---|---:|---:|---:|---:|---|
| battery | image_seq | 5 | 2 | 11 | 28 | 电池图标 - 字宽11字高28/11-28电池图标3.png |
| hero_digits | digits | 45 | 3 | 28 | 27 | 10 |
| mode_label | text | 88 | 4 | 23 | 7 | RAMP |
| mode_icon | image | 94 | 19 | 24 | 12 | Curing_Lite光固化机产品 - UI设计初稿/ramp.png |

## TURBO_RUNNING

State: `battery=3, mode=TURBO, phase=running, seconds=10`

Golden BIN: `golden/turbo_running.bin`  
Reference PNG: `reference/turbo_running.png`  
SHA-256: `090fad20eb075bd6109085fedd6d56cb366fe66151b4e08cd41b8720c38bb70f`

| ID | Type | X | Y | W | H | Asset / Text |
|---|---|---:|---:|---:|---:|---|
| battery | image_seq | 5 | 2 | 11 | 28 | 电池图标 - 字宽11字高28/11-28电池图标3.png |
| hero_digits | digits | 45 | 3 | 28 | 27 | 10 |
| mode_label | text | 88 | 4 | 29 | 7 | TURBO |
| running_icon | image | 94 | 19 | 24 | 12 | Curing_Lite光固化机产品 - UI设计初稿/running.png |

## TURBO_STANDBY

State: `battery=3, mode=TURBO, phase=standby, seconds=10`

Golden BIN: `golden/turbo_standby.bin`  
Reference PNG: `reference/turbo_standby.png`  
SHA-256: `0317a7dcf543ecd7a9a6997f8fdd15b1ab833c33a58cedf5efaf6b82f462fd39`

| ID | Type | X | Y | W | H | Asset / Text |
|---|---|---:|---:|---:|---:|---|
| battery | image_seq | 5 | 2 | 11 | 28 | 电池图标 - 字宽11字高28/11-28电池图标3.png |
| hero_digits | digits | 45 | 3 | 28 | 27 | 10 |
| mode_label | text | 88 | 4 | 29 | 7 | TURBO |
| mode_icon | image | 94 | 19 | 24 | 12 | Curing_Lite光固化机产品 - UI设计初稿/turbo.png |
