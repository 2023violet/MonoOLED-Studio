# OLED UI Code AI Handoff

Implementation truth order:

1. `ui_contract.json` — machine-readable geometry/state contract.
2. `golden/*.bin` — pixel truth; compare framebuffer byte-for-byte.
3. `UI_SPEC.md` — human-readable implementation guide.
4. `validation_report.md`, `batch_validation.md`, and `design_rules.md` — release gates.
5. `thumbnail_wall.png` — fast visual review; never use it to infer coordinates.
6. `c_headers/*.h` — optional VLSB asset/frame arrays generated from Golden truth.

Do not infer coordinates from screenshots when contract JSON is available.
